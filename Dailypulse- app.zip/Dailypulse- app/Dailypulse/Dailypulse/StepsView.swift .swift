import SwiftUI

struct StepsView: View {
    var body: some View {
        VStack {
            Text("Steps Tracking is currently unavailable.")
                .font(.largeTitle)
                .padding()
            
            Image(systemName: "figure.walk")
                .resizable()
                .scaledToFit()
                .frame(width: 200, height: 200)
                .padding()
        }
    }
}
