import SwiftUI
import FSCalendar

struct ScheduleView: UIViewRepresentable {
    func makeUIView(context: Context) -> FSCalendar {
        let calendar = FSCalendar()
        return calendar
    }

    func updateUIView(_ uiView: FSCalendar, context: Context) {}
}
