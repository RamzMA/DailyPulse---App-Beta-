import SwiftUI
import Combine
import FirebaseAuth

class AppState: ObservableObject {
    @Published var isAuthenticated: Bool = false
    @Published var user: User?

    init() {
        self.user = Auth.auth().currentUser
        self.isAuthenticated = self.user != nil
    }

    func logout() {
        do {
            try Auth.auth().signOut()
            self.user = nil
            self.isAuthenticated = false
        } catch {
            print("Error signing out: \(error.localizedDescription)")
        }
    }
}
