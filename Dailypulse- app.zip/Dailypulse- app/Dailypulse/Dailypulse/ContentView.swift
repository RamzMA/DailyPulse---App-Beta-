import SwiftUI
import FirebaseAuth

struct ContentView: View {
    @EnvironmentObject var appState: AppState

    var body: some View {
        Group {
            if appState.isAuthenticated {
                MainTabView()
            } else {
                AuthenticationView()
            }
        }
        .onAppear(perform: checkAuthentication)
    }

    private func checkAuthentication() {
        if let user = Auth.auth().currentUser {
            appState.user = user
            appState.isAuthenticated = true
        } else {
            appState.isAuthenticated = false
        }
    }
}

struct MainTabView: View {
    @EnvironmentObject var appState: AppState

    var body: some View {
        TabView {
            StepsView()
                .tabItem {
                    Image(systemName: "figure.walk")
                    Text("Steps")
                }

            MessagesView()
                .tabItem {
                    Image(systemName: "message")
                    Text("Messages")
                }

            ScheduleView()
                .tabItem {
                    Image(systemName: "calendar")
                    Text("Schedule")
                }

            ExerciseView()
                .tabItem {
                    Image(systemName: "bolt")
                    Text("Exercise")
                }

            SleepView()
                .tabItem {
                    Image(systemName: "bed.double")
                    Text("Sleep")
                }

            ProfileView()
                .tabItem {
                    Image(systemName: "person")
                    Text("Profile")
                }
        }
    }
}

struct ProfileView: View {
    @EnvironmentObject var appState: AppState

    var body: some View {
        VStack {
            Text("Logged in as: \(appState.user?.email ?? "Unknown")")
                .padding()

            Button(action: appState.logout) {
                Text("Logout")
                    .padding()
                    .background(Color.red)
                    .foregroundColor(.white)
                    .cornerRadius(8)
            }
        }
        .padding()
    }
}
