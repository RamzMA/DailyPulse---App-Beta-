import SwiftUI
import FirebaseFirestore

struct ExerciseView: View {
    @State private var workout: String = ""
    @State private var workouts: [String] = []
    private let db = Firestore.firestore()

    var body: some View {
        VStack {
            TextField("Enter workout", text: $workout)
                .padding()
                .background(Color(.secondarySystemBackground))

            Button(action: addWorkout) {
                Text("Add Workout")
                    .padding()
                    .background(Color.green)
                    .foregroundColor(.white)
                    .cornerRadius(8)
            }

            List(workouts, id: \.self) { workout in
                Text(workout)
            }
        }
        .padding()
        .onAppear(perform: fetchWorkouts)
    }

    private func fetchWorkouts() {
        db.collection("workouts").addSnapshotListener { querySnapshot, error in
            if let querySnapshot = querySnapshot {
                self.workouts = querySnapshot.documents.map { $0["workout"] as? String ?? "" }
            }
        }
    }

    private func addWorkout() {
        let workoutData = ["workout": workout]
        db.collection("workouts").addDocument(data: workoutData) { error in
            if let error = error {
                print("Error adding workout: \(error)")
            } else {
                self.workout = ""
            }
        }
    }
}
