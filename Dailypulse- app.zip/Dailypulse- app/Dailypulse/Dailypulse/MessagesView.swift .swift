import SwiftUI
import FirebaseFirestore
import FirebaseFirestoreSwift

struct MessagesView: View {
    @EnvironmentObject var appState: AppState
    @State private var messages: [Message] = []
    @State private var newMessage: String = ""
    private let db = Firestore.firestore()

    var body: some View {
        VStack {
            ScrollView {
                VStack(alignment: .leading) {
                    ForEach(messages) { message in
                        HStack {
                            if message.senderId == appState.user?.uid {
                                Spacer()
                                Text(message.text ?? "")
                                    .padding()
                                    .background(Color.blue)
                                    .foregroundColor(.white)
                                    .cornerRadius(10)
                                    .frame(maxWidth: .infinity, alignment: .trailing)
                            } else {
                                Text(message.text ?? "")
                                    .padding()
                                    .background(Color.gray.opacity(0.2))
                                    .cornerRadius(10)
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                Spacer()
                            }
                        }
                        .padding(.horizontal)
                        .padding(.vertical, 4)
                    }
                }
            }
            .padding(.top)

            HStack {
                TextField("Enter message", text: $newMessage)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .frame(minHeight: 30)

                Button(action: sendMessage) {
                    Image(systemName: "paperplane.fill")
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .clipShape(Circle())
                }
            }
            .padding()
        }
        .onAppear(perform: fetchMessages)
    }

    private func fetchMessages() {
        db.collection("messages").order(by: "timestamp", descending: false).addSnapshotListener { querySnapshot, error in
            if let querySnapshot = querySnapshot {
                self.messages = querySnapshot.documents.compactMap { document -> Message? in
                    try? document.data(as: Message.self)
                }
            }
        }
    }

    private func sendMessage() {
        guard !newMessage.isEmpty, let user = appState.user else { return }
        let message = Message(id: UUID().uuidString, text: newMessage, timestamp: Date(), senderId: user.uid)
        do {
            try db.collection("messages").document(message.id ?? UUID().uuidString).setData(from: message)
            newMessage = ""
        } catch {
            print("Error adding message: \(error)")
        }
    }
}

struct Message: Identifiable, Codable {
    @DocumentID var id: String? = UUID().uuidString
    var text: String?
    var timestamp: Date
    var senderId: String

    enum CodingKeys: String, CodingKey {
        case id
        case text
        case timestamp
        case senderId
    }
}
