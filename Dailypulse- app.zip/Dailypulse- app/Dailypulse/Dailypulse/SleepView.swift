import SwiftUI
import FirebaseFirestore

struct SleepView: View {
    @State private var startTime: String = ""
    @State private var endTime: String = ""
    @State private var sleepLogs: [String] = []
    private let db = Firestore.firestore()

    var body: some View {
        VStack {
            TextField("Enter sleep start time", text: $startTime)
                .padding()
                .background(Color(.secondarySystemBackground))

            TextField("Enter sleep end time", text: $endTime)
                .padding()
                .background(Color(.secondarySystemBackground))

            Button(action: addSleepLog) {
                Text("Log Sleep")
                    .padding()
                    .background(Color.green)
                    .foregroundColor(.white)
                    .cornerRadius(8)
            }

            List(sleepLogs, id: \.self) { log in
                Text(log)
            }
        }
        .padding()
        .onAppear(perform: fetchSleepLogs)
    }

    private func fetchSleepLogs() {
        db.collection("sleepLogs").addSnapshotListener { querySnapshot, error in
            if let querySnapshot = querySnapshot {
                self.sleepLogs = querySnapshot.documents.map { "\($0["startTime"] as? String ?? "") - \($0["endTime"] as? String ?? "")" }
            }
        }
    }

    private func addSleepLog() {
        let sleepLogData = ["startTime": startTime, "endTime": endTime]
        db.collection("sleepLogs").addDocument(data: sleepLogData) { error in
            if let error = error {
                print("Error logging sleep: \(error)")
            } else {
                self.startTime = ""
                self.endTime = ""
            }
        }
    }
}
